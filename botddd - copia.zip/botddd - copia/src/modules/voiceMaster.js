const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ChannelType } = require('discord.js');

async function sendVoiceMasterPanel(channel) {
  try {
    if (!channel || !channel.isTextBased()) {
      console.error('❌ El canal proporcionado para VoiceMaster no es de texto.');
      return;
    }

    const guild = channel.guild;
    const serverIcon = guild.iconURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setTitle('VoiceMaster Interface')
      .setDescription('Manage your voice channel by using the buttons below.')
      .addFields(
        {
          name: 'Button Usage',
          value: 
            '` 🔒 ` — Lock the voice channel\n' +
            '` 🔓 ` — Unlock the voice channel\n' +
            '` 👁️ ` — Hide the voice channel\n' +
            '` 🌐 ` — Reveal the voice channel\n' +
            '` 🎙️ ` — Mute a user from voice\n' +
            '` 🔌 ` — Disconnect a user\n' +
            '` 🎮 ` — Start voice activity\n' +
            '` ℹ️ ` — View channel info\n' +
            '` ➕ ` — Increase user limit\n' +
            '` ➖ ` — Decrease user limit',
          inline: false
        }
      )
      .setFooter({ text: 'Silly Cats Security • VoiceMaster' });

    if (serverIcon) {
      embed.setThumbnail(serverIcon);
    }

    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('vm_lock').setEmoji('🔒').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_unlock').setEmoji('🔓').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_hide').setEmoji('👁️').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_unhide').setEmoji('🌐').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_mute').setEmoji('🎙️').setStyle(ButtonStyle.Secondary)
    );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('vm_disconnect').setEmoji('🔌').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_activity').setEmoji('🎮').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_info').setEmoji('ℹ️').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_limit_up').setEmoji('➕').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('vm_limit_down').setEmoji('➖').setStyle(ButtonStyle.Secondary)
    );

    await channel.send({ embeds: [embed], components: [row1, row2] });
    console.log(`✅ Panel VoiceMaster estético enviado en #${channel.name}`);
  } catch (err) {
    console.error('❌ Error al enviar el panel VoiceMaster:', err);
  }
}

// Lógica de creación automática de canales al entrar a "Join to Create"
async function handleVoiceStateUpdate(oldState, newState) {
  const guild = newState.guild;
  const member = newState.member;

  if (newState.channel?.name === 'Join to Create') {
    try {
      const category = newState.channel.parent;
      const channelName = `${member.user.username}'s channel`;

      const createdChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildVoice,
        parent: category ? category.id : null,
        permissionOverwrites: [
          {
            id: member.id,
            allow: ['ManageChannels', 'MuteMembers', 'DeafenMembers', 'MoveMembers']
          }
        ]
      });

      await member.voice.setChannel(createdChannel).catch(() => {});
    } catch (err) {
      console.error('Error al crear canal de VoiceMaster:', err);
    }
  }

  // Borrar canal temporal si se queda vacío
  if (oldState.channel && oldState.channel.name.endsWith("'s channel") && oldState.channel.members.size === 0) {
    await oldState.channel.delete().catch(() => {});
  }
}

// Manejo de interacciones de los botones de VoiceMaster
async function handleVoiceMasterButtons(interaction) {
  const member = interaction.member;
  const voiceChannel = member.voice.channel;

  if (!voiceChannel || !voiceChannel.name.endsWith("'s channel")) {
    return interaction.reply({ content: '❌ Debes estar en tu propio canal de voz privado para usar estos botones.', ephemeral: true });
  }

  const customId = interaction.customId;

  try {
    if (customId === 'vm_lock') {
      await voiceChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, { Connect: false });
      return interaction.reply({ content: '🔒 Canal de voz bloqueado.', ephemeral: true });
    }
    if (customId === 'vm_unlock') {
      await voiceChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, { Connect: null });
      return interaction.reply({ content: '🔓 Canal de voz desbloqueado.', ephemeral: true });
    }
    if (customId === 'vm_hide') {
      await voiceChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, { ViewChannel: false });
      return interaction.reply({ content: '👁️ Canal oculto.', ephemeral: true });
    }
    if (customId === 'vm_unhide') {
      await voiceChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, { ViewChannel: null });
      return interaction.reply({ content: '🌐 Canal visible.', ephemeral: true });
    }
    if (customId === 'vm_info') {
      return interaction.reply({ content: `ℹ️ **Info del Canal**\nPropietario: ${member}\nMiembros conectados: ${voiceChannel.members.size}`, ephemeral: true });
    }
  } catch (err) {
    return interaction.reply({ content: '❌ Ocurrió un error al gestionar el canal.', ephemeral: true });
  }
}

module.exports = { sendVoiceMasterPanel, handleVoiceStateUpdate, handleVoiceMasterButtons };