const { ActivityType } = require('discord.js');
const { loadCache } = require('../database');

function handleReady(client) {
  client.once('ready', () => {
    // Carga de base de datos a memoria en el arranque
    loadCache();

    console.log(`=========================================`);
    console.log(`🤖 Bot listo e iniciado como: ${client.user.tag}`);
    console.log(`🛡️ Sistema Anti-Nuke y Anti-Raid Cargaros en Memoria`);
    console.log(`=========================================`);

    client.user.setActivity('proteger este servidor | ,security help', { type: ActivityType.Watching });
  });
}

module.exports = { handleReady };