const https = require('https');
const { 
  isWhitelisted, addWhitelist, removeWhitelist, getWhitelist, 
  getConfig, updateConfig, addHardban, removeHardban,
  setJailedUser, getJailedUserRoles, removeJailedUser 
} = require('../database');
const { PermissionFlagsBits, EmbedBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { sendVoiceMasterPanel } = require('../modules/voiceMaster');
const { sendModLog } = require('../logger');

// Agente HTTPS para forzar IPv4 y evitar el error "fetch failed" en Node.js
const agent = new https.Agent({
  family: 4,
  keepAlive: true
});

// Historiales globales en memoria
if (!global.gifHistory) global.gifHistory = new Map();
if (!global.snipes) global.snipes = new Map();

function createEmbed(description, color = 0x2b2d31) {
  return new EmbedBuilder().setDescription(description).setColor(color);
}

function parseDuration(timeStr) {
  if (!timeStr) return null;
  const match = timeStr.match(/^(\d+)([mhd])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  if (unit === 'm') return value * 60 * 1000;
  if (unit === 'h') return value * 60 * 60 * 1000;
  if (unit === 'd') return value * 24 * 60 * 60 * 1000;
  return null;
}

async function handleCommands(message) {
  const prefix = process.env.PREFIX || ',';
  if (!message.content.startsWith(prefix) || message.author.bot || !message.guild) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  const guild = message.guild;
  const guildId = guild.id;

  // HELP
  if (command === 'help' || command === 'cmds' || command === 'comandos') {
    const helpEmbed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setTitle('🐾 Panel de Comandos de Silly Cats Security')
      .setDescription(`Prefijo del servidor: \`${prefix}\`\n*Escribe cualquier comando de moderación sin argumentos para ver su guía de uso.*`)
      .addFields(
        { 
          name: '🛠️ **Configuración & Setup**', 
          value: `\`${prefix}setup\` - Configuración de canales privados y logs.\n\`${prefix}vsetup\` - Configuración del panel VoiceMaster.\n\`${prefix}security status\` - Estado del bot.` 
        },
        { 
          name: '🔒 **Cárcel, Lockdown & Whitelist**', 
          value: `\`${prefix}whitelist\` - Guía e información de la lista blanca.\n\`${prefix}jail @usuario [razón]\` - Encarcela a un usuario.\n\`${prefix}unjail @usuario\` - Libera a un usuario.\n\`${prefix}lock [razón]\` / \`${prefix}unlock\` - Bloquea/Desbloquea.\n\`${prefix}lockdown on/off\` - Bloqueo masivo.` 
        },
        { 
          name: '🛡️ **Moderación & Sanciones**', 
          value: `\`${prefix}ban @usuario [razón]\` - Ban con registro en logs.\n\`${prefix}hardban @usuario\` (\`${prefix}hb\`) - Ban permanente SQLite.\n\`${prefix}unban [ID]\` - Desbanea.\n\`${prefix}kick @usuario\` - Expulsa.\n\`${prefix}mute @usuario [tiempo]\` - Silencia (\`10m\`, \`1h\`).\n\`${prefix}unmute @usuario\` - Quita silencio.\n\`${prefix}fn @usuario [apodo]\` - Cambia apodo.` 
        },
        { 
          name: '🎨 **Perfiles, Utiles & Snipes**', 
          value: `\`${prefix}avatar [@user]\` (\`${prefix}av\`) - Foto de perfil HD.\n\`${prefix}banner [@user]\` - Banner de perfil HD.\n\`${prefix}s\` (\`${prefix}snipe\`) - Ver mensaje borrado.\n\`${prefix}cs\` (\`${prefix}clearsnipe\`) - Limpiar snipes.\n\`${prefix}r @usuario [rol]\` - Dar/Quitar rol.\n\`${prefix}purge [cant]\` - Borra mensajes.\n\`${prefix}nuke\` - Recrea el canal.` 
        },
        { 
          name: '🌐 **Búsqueda Social**', 
          value: `\`${prefix}roblox profile [user]\` - Perfil de Roblox.\n\`${prefix}ig [cuenta]\` - Perfil de Instagram.\n\`${prefix}tiktok [cuenta]\` - Perfil de TikTok.` 
        },
        { 
          name: '🎭 **Interacciones SFW (Anime)**', 
          value: `\`${prefix}kiss\`, \`${prefix}hug\`, \`${prefix}slap\`, \`${prefix}pat\`, \`${prefix}kill\`, \`${prefix}cuddle\`, \`${prefix}poke\`, \`${prefix}tickle\`, \`${prefix}bite\`, \`${prefix}handhold\`, \`${prefix}highfive\`, \`${prefix}wave\`, \`${prefix}smile\`, \`${prefix}wink\`, \`${prefix}blush\`, \`${prefix}punch\`, \`${prefix}yeet\`, \`${prefix}dance\`` 
        }
      )
      .setFooter({ text: `Silly Cats Security • Solicitado por ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
      .setTimestamp();

    return message.reply({ embeds: [helpEmbed] });
  }

  // AVATAR
  if (command === 'avatar' || command === 'av') {
    const targetUser = message.mentions.users.first() || 
                       (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null) || 
                       message.author;

    const avatarUrl = targetUser.displayAvatarURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setAuthor({ name: `Avatar de ${targetUser.tag}`, iconURL: avatarUrl })
      .setImage(avatarUrl)
      .setFooter({ text: `ID: ${targetUser.id}` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('Abrir original').setURL(avatarUrl).setStyle(ButtonStyle.Link)
    );

    return message.reply({ embeds: [embed], components: [row] });
  }

  // BANNER
  if (command === 'banner') {
    const targetUser = message.mentions.users.first() || 
                       (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null) || 
                       message.author;

    const fetchedUser = await message.client.users.fetch(targetUser.id, { force: true }).catch(() => null);
    const bannerUrl = fetchedUser?.bannerURL({ dynamic: true, size: 1024 });

    if (!bannerUrl) {
      return message.reply({ embeds: [createEmbed(`ℹ️ **${targetUser.tag}** no tiene un banner personalizado.`)] });
    }

    const embed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setAuthor({ name: `Banner de ${targetUser.tag}`, iconURL: targetUser.displayAvatarURL({ dynamic: true }) })
      .setImage(bannerUrl)
      .setFooter({ text: `ID: ${targetUser.id}` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('Abrir original').setURL(bannerUrl).setStyle(ButtonStyle.Link)
    );

    return message.reply({ embeds: [embed], components: [row] });
  }

  // SNIPE (,s / ,snipe)
  if (command === 's' || command === 'snipe') {
    const channelSnipes = global.snipes?.get(message.channel.id);

    if (!channelSnipes || channelSnipes.length === 0) {
      return message.reply({ embeds: [createEmbed('❌ No hay ningún mensaje eliminado recientemente en este canal.')] });
    }

    const index = (parseInt(args[0]) || 1) - 1;
    if (index < 0 || index >= channelSnipes.length) {
      return message.reply({ embeds: [createEmbed(`❌ Solo hay **${channelSnipes.length}** mensajes eliminados registrados.`)] });
    }

    const targetSnipe = channelSnipes[index];
    const secondsAgo = Math.floor((Date.now() - targetSnipe.timestamp) / 1000);

    const snipeEmbed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setAuthor({ 
        name: targetSnipe.author.username, 
        iconURL: targetSnipe.author.displayAvatarURL({ dynamic: true }) 
      })
      .setDescription(targetSnipe.content || '*El mensaje solo contenía un archivo/imagen.*')
      .setFooter({ 
        text: `Deleted ${secondsAgo} seconds ago • ${index + 1}/${channelSnipes.length} messages`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    if (targetSnipe.image) {
      snipeEmbed.setImage(targetSnipe.image);
    }

    return message.reply({ embeds: [snipeEmbed] });
  }

  // CLEAR SNIPE (,cs / ,clearsnipe)
  if (command === 'cs' || command === 'clearsnipe') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return message.reply({ embeds: [createEmbed('⚠️ Te falta el permiso: `manage_messages`', 0xF1C40F)] });
    }

    const channelSnipes = global.snipes?.get(message.channel.id);
    if (!channelSnipes || channelSnipes.length === 0) {
      return message.reply({ embeds: [createEmbed('ℹ️ El historial de mensajes eliminados de este canal ya está vacío.')] });
    }

    global.snipes.delete(message.channel.id);
    return message.reply({ embeds: [createEmbed('🧹 **Se ha limpiado el historial de mensajes eliminados de este canal.**', 0x57F287)] });
  }

  // INTERACCIONES SFW (MULTI-API FALLBACK)
  const actionTexts = {
    kiss: (a, t) => `💋 **${a}** le dio un beso a **${t}**!`,
    hug: (a, t) => `🫂 **${a}** le dio un abrazo a **${t}**!`,
    slap: (a, t) => `🖐️ **${a}** le dio una bofetada a **${t}**!`,
    pat: (a, t) => `🫳 **${a}** le acarició la cabeza a **${t}**!`,
    kill: (a, t) => `🔪 **${a}** acabó con **${t}**!`,
    cuddle: (a, t) => `🤗 **${a}** se acurrucó con **${t}**!`,
    poke: (a, t) => `👉 **${a}** le dio un toque a **${t}**!`,
    tickle: (a, t) => `🤏 **${a}** le hizo cosquillas a **${t}**!`,
    bite: (a, t) => `🦷 **${a}** le dio un mordisco a **${t}**!`,
    handhold: (a, t) => `🤝 **${a}** le agarró la mano a **${t}**!`,
    highfive: (a, t) => `🙌 **${a}** le dio los cinco a **${t}**!`,
    wave: (a, t) => `👋 **${a}** le saludó a **${t}**!`,
    smile: (a, t) => `😊 **${a}** le sonrió a **${t}**!`,
    wink: (a, t) => `😉 **${a}** le guiñó el ojo a **${t}**!`,
    blush: (a, t) => `😳 **${a}** se sonrojó al mirar a **${t}**!`,
    punch: (a, t) => `👊 **${a}** le dio un puñetazo a **${t}**!`,
    yeet: (a, t) => `🚀 **${a}** lanzó por los aires a **${t}**!`,
    dance: (a, t) => `💃 **${a}** se puso a bailar con **${t}**!`
  };

  if (Object.keys(actionTexts).includes(command)) {
    const targetUser = message.mentions.users.first() || 
                       (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null);

    if (!targetUser) return message.reply({ embeds: [createEmbed(`❌ Debes mencionar a alguien. Ej: \`${prefix}${command} @usuario\``)] });
    if (targetUser.id === message.author.id) return message.reply({ embeds: [createEmbed('❌ No puedes realizar esta interacción contigo mismo/a... 😿')] });

    try {
      const historyKey = `${message.author.id}-${command}`;
      if (!global.gifHistory.has(historyKey)) global.gifHistory.set(historyKey, []);
      const usedGifs = global.gifHistory.get(historyKey);

      let selectedGif = null;

      // 1. INTENTO CON WAIFU.PICS
      for (let attempts = 0; attempts < 2; attempts++) {
        try {
          const res = await fetch(`https://api.waifu.pics/sfw/${command}`, { agent, headers: { 'User-Agent': 'Mozilla/5.0' } });
          const data = await res.json();
          if (data?.url && !usedGifs.includes(data.url)) {
            selectedGif = data.url;
            break;
          } else if (data?.url && !selectedGif) {
            selectedGif = data.url;
          }
        } catch (e) {}
      }

      // 2. INTENTO CON OTAKUGIFS (RESPALDO 1)
      if (!selectedGif) {
        try {
          const res = await fetch(`https://api.otakugifs.xyz/gif?reaction=${command}`, { agent, headers: { 'User-Agent': 'Mozilla/5.0' } });
          const data = await res.json();
          if (data?.url) selectedGif = data.url;
        } catch (e) {}
      }

      // 3. INTENTO CON NEKOS.LIFE (RESPALDO 2)
      if (!selectedGif) {
        try {
          const nekosEndpoint = command === 'kiss' ? 'kiss' : command === 'hug' ? 'hug' : command === 'pat' ? 'pat' : 'slap';
          const res = await fetch(`https://nekos.life/api/v2/img/${nekosEndpoint}`, { agent });
          const data = await res.json();
          if (data?.url) selectedGif = data.url;
        } catch (e) {}
      }

      if (!selectedGif) return message.reply({ embeds: [createEmbed('❌ No se pudo obtener la animación en este momento.')] });

      usedGifs.push(selectedGif);
      if (usedGifs.length > 10) usedGifs.shift();

      const embed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setDescription(actionTexts[command](message.author.username, targetUser.username))
        .setImage(selectedGif)
        .setFooter({ text: `Silly Cats • ${command.toUpperCase()}` });

      return message.reply({ embeds: [embed] });
    } catch (err) {
      return message.reply({ embeds: [createEmbed(`❌ Error: \`${err.message}\``)] });
    }
  }

  // LOCK & UNLOCK
  if (command === 'lock') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `manage_channels`', 0xF1C40F)] });
    const reason = args.join(' ') || 'Sin razón especificada';
    try {
      await message.channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false });
      const embed = new EmbedBuilder().setColor(0xED4245).setTitle('🔒 Canal Bloqueado').setDescription(`Este canal ha sido bloqueado por ${message.author}.\n**Razón:** ${reason}`).setTimestamp();
      await sendModLog(guild, 'lock', message.author, message.author, `Canal #${message.channel.name} bloqueado:${reason}`);
      return message.reply({ embeds: [embed] });
    } catch (err) { return message.reply({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); }
  }

  if (command === 'unlock') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `manage_channels`', 0xF1C40F)] });
    try {
      await message.channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: null });
      const embed = new EmbedBuilder().setColor(0x57F287).setTitle('🔓 Canal Desbloqueado').setDescription(`Este canal ha sido desbloqueado por ${message.author}.`).setTimestamp();
      await sendModLog(guild, 'unlock', message.author, message.author, `Canal #${message.channel.name} desbloqueado`);
      return message.reply({ embeds: [embed] });
    } catch (err) { return message.reply({ embeds: [createEmbed(`❌ Error: \`${err.message}\``)] }); }
  }

  if (command === 'lockdown') {
    if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) return message.reply({ embeds: [createEmbed('⚠️ Requieres permisos de Administrador.', 0xF1C40F)] });
    const sub = args[0]?.toLowerCase();

    if (!sub || (sub !== 'on' && sub !== 'off' && sub !== 'start' && sub !== 'end')) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🚨 Guía de Uso: Lockdown (Bloqueo Masivo)')
        .setDescription('**¿Para qué sirve?**\nBloquea o desbloquea masivamente la capacidad de enviar mensajes en **todos los canales de texto** del servidor simultáneamente. Útil durante raideos o ataques.')
        .addFields(
          { name: '🔹 **Activar Lockdown**', value: `\`${prefix}lockdown on\` — Bloquea el envío de mensajes a @everyone en todos los canales.` },
          { name: '🔹 **Desactivar Lockdown**', value: `\`${prefix}lockdown off\` — Restaura los permisos normales en todos los canales.` }
        )
        .setFooter({ text: 'Requiere permiso: Administrador' });
      return message.reply({ embeds: [guideEmbed] });
    }

    if (sub === 'on' || sub === 'start') {
      const msg = await message.reply({ embeds: [createEmbed('⏳ Iniciando bloqueo masivo...')] });
      let count = 0;
      const channels = await guild.channels.fetch();
      for (const [, ch] of channels) {
        if (ch && ch.isTextBased() && !ch.isThread()) {
          await ch.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false }).catch(() => {});
          count++;
        }
      }
      await sendModLog(guild, 'lockdown', message.author, message.author, `Lockdown activado en ${count} canales`);
      return msg.edit({ embeds: [createEmbed(`🚨 **SERVER LOCKDOWN ACTIVADO**\nSe han bloqueado **${count}** canales.`)] });
    }

    if (sub === 'off' || sub === 'end') {
      const msg = await message.reply({ embeds: [createEmbed('⏳ Desactivando bloqueo masivo...')] });
      let count = 0;
      const channels = await guild.channels.fetch();
      for (const [, ch] of channels) {
        if (ch && ch.isTextBased() && !ch.isThread()) {
          await ch.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: null }).catch(() => {});
          count++;
        }
      }
      await sendModLog(guild, 'lockdown_end', message.author, message.author, `Lockdown desactivado en ${count} canales`);
      return msg.edit({ embeds: [createEmbed(`🟢 **SERVER LOCKDOWN DESACTIVADO**\nSe ha restaurado el envío de mensajes en **${count}** canales.`)] });
    }
  }

  // ROBLOX
  if (command === 'roblox' || command === 'rbx') {
    const sub = args[0]?.toLowerCase();
    const username = sub === 'profile' ? args[1] : args[0];
    if (!username) return message.reply({ embeds: [createEmbed('❌ Uso: `,roblox profile [usuario]`')] });

    try {
      const userReq = await fetch('https://users.roblox.com/v1/usernames/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
        agent
      });
      const userData = await userReq.json();
      if (!userData?.data?.[0]) return message.reply({ embeds: [createEmbed(`❌ No se encontró el usuario \`${username}\` en Roblox.`)] });

      const user = userData.data[0];
      const userId = user.id;

      const [detailsRes, friendsRes, followersRes, followingRes, groupsRes, avatarRes] = await Promise.all([
        fetch(`https://users.roblox.com/v1/users/${userId}`, { agent }).then(r => r.json()).catch(() => ({})),
        fetch(`https://friends.roblox.com/v1/users/${userId}/friends/count`, { agent }).then(r => r.json()).catch(() => ({ count: 0 })),
        fetch(`https://friends.roblox.com/v1/users/${userId}/followers/count`, { agent }).then(r => r.json()).catch(() => ({ count: 0 })),
        fetch(`https://friends.roblox.com/v1/users/${userId}/followings/count`, { agent }).then(r => r.json()).catch(() => ({ count: 0 })),
        fetch(`https://groups.roblox.com/v1/users/${userId}/groups/roles`, { agent }).then(r => r.json()).catch(() => ({ data: [] })),
        fetch(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=352x352&format=Png&isCircular=false`, { agent }).then(r => r.json()).catch(() => ({}))
      ]);

      const avatarUrl = avatarRes?.data?.[0]?.imageUrl || 'https://tr.rbxcdn.com/30day-avatar/150/150/Avatar/Png';
      const joinDate = detailsRes.created ? new Date(detailsRes.created) : new Date();
      const joinFormatted = joinDate.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
      const yearsAgo = new Date().getFullYear() - joinDate.getFullYear();

      const embed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setAuthor({ name: 'Roblox - info de perfil' })
        .setTitle(detailsRes.displayName || user.name)
        .setDescription(`\`@${user.name}\` · \`#${userId}\`\n${detailsRes.description || '*Sin descripción*'}`)
        .addFields({
          name: '🟢 En línea',
          value: `👥 **${friendsRes.count || 0}** friends\n👤 **${followersRes.count || 0}** followers\n👤 **${followingRes.count || 0}** following\n👥 **${groupsRes.data?.length || 0}** groups\n📅 Joined: ${joinFormatted} - hace${yearsAgo} años`
        })
        .setThumbnail(avatarUrl);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel('Roblox Profile').setURL(`https://www.roblox.com/users/${userId}/profile`).setStyle(ButtonStyle.Link),
        new ButtonBuilder().setLabel('Groups').setURL(`https://www.roblox.com/users/${userId}/profile#!/groups`).setStyle(ButtonStyle.Link)
      );

      return message.reply({ embeds: [embed], components: [row] });
    } catch (err) {
      return message.reply({ embeds: [createEmbed(`❌ Error: \`${err.message}\``)] });
    }
  }

  // INSTAGRAM & TIKTOK
  if (command === 'ig' || command === 'instagram') {
    const handle = args[0]?.replace('@', '');
    if (!handle) return message.reply({ embeds: [createEmbed('❌ Especifica un usuario. Ej: `,ig usuario`')] });
    const embed = new EmbedBuilder()
      .setColor(0xE1306C)
      .setAuthor({ name: 'Instagram Lookup' })
      .setTitle(`@${handle}`)
      .setDescription(`Perfil de **[@${handle}](https://instagram.com/${handle})** en Instagram.`)
      .setThumbnail(`https://unavatar.io/instagram/${handle}`);
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Ver en Instagram').setURL(`https://instagram.com/${handle}`).setStyle(ButtonStyle.Link));
    return message.reply({ embeds: [embed], components: [row] });
  }

  if (command === 'tiktok' || command === 'tk') {
    const handle = args[0]?.replace('@', '');
    if (!handle) return message.reply({ embeds: [createEmbed('❌ Especifica un usuario. Ej: `,tiktok usuario`')] });
    const embed = new EmbedBuilder()
      .setColor(0x000000)
      .setAuthor({ name: 'TikTok Lookup' })
      .setTitle(`@${handle}`)
      .setDescription(`Perfil de **[@${handle}](https://tiktok.com/@${handle})** en TikTok.`)
      .setThumbnail(`https://unavatar.io/tiktok/${handle}`);
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Abrir TikTok').setURL(`https://tiktok.com/@${handle}`).setStyle(ButtonStyle.Link));
    return message.reply({ embeds: [embed], components: [row] });
  }

  // SECURITY STATUS
  if (command === 'security') {
    const sub = args[0]?.toLowerCase();
    const cfg = getConfig(guildId);
    if (sub === 'status') {
      const statusEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🛡️ Status de Silly Cats Security')
        .addFields(
          { name: 'Anti-Nuke', value: cfg.antinuke !== false ? '🟢 **Activo**' : '🔴 **Inactivo**', inline: true },
          { name: 'Logs Generales', value: cfg.logChannelId ? `<#${cfg.logChannelId}>` : '`No configurado`', inline: true },
          { name: 'Logs Mensajes', value: cfg.msgLogChannelId ? `<#${cfg.msgLogChannelId}>` : '`No configurado`', inline: true },
          { name: 'Rol de Jail', value: cfg.jailRoleId ? `<@&${cfg.jailRoleId}>` : '`No configurado`', inline: true }
        );
      return message.reply({ embeds: [statusEmbed] });
    }
  }

  // MUTE / UNMUTE GUÍAS & ACCIONES
  if (command === 'mute' || command === 'timeout') {
    if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `moderate_members`', 0xF1C40F)] });
    
    const targetUser = message.mentions.users.first() || (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null);
    
    if (!targetUser || !args[1]) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🔇 Guía de Uso: Mute / Timeout')
        .setDescription('**¿Para qué sirve?**\nAplica un silencio temporal al usuario impidiéndole escribir o hablar en voz.')
        .addFields(
          { name: '📌 **Sintaxis**', value: `\`${prefix}mute @usuario [tiempo] [razón]\`` },
          { name: '⏳ **Formatos de tiempo**', value: '`10m` (10 minutos)\n`1h` (1 hora)\n`1d` (1 día)' },
          { name: '💡 **Ejemplo**', value: `\`${prefix}mute @usuario 30m Spam continuo\`` }
        );
      return message.reply({ embeds: [guideEmbed] });
    }

    const durationMs = parseDuration(args[1]);
    if (!durationMs) return message.reply({ embeds: [createEmbed('❌ Tiempo inválido. Usa un formato correcto como `10m`, `1h`, o `1d`.')] });
    
    const reason = args.slice(2).join(' ') || 'No reason provided';
    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) return message.reply({ embeds: [createEmbed('❌ El usuario no está en el servidor.')] });

    try {
      await member.timeout(durationMs, reason);
      await sendModLog(guild, 'mute', targetUser, message.author, `${reason} (${args[1]})`);
      return message.reply({ embeds: [createEmbed(`🔇 **${targetUser.tag}** silenciado por \`${args[1]}\`.`)] });
    } catch (e) { return message.reply({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); }
  }

  if (command === 'unmute') {
    if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `moderate_members`', 0xF1C40F)] });
    
    const targetUser = message.mentions.users.first() || (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null);
    if (!targetUser) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🔊 Guía de Uso: Unmute')
        .setDescription('Retira el tiempo de silencio asignado a un usuario.')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}unmute @usuario\`` });
      return message.reply({ embeds: [guideEmbed] });
    }

    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) return message.reply({ embeds: [createEmbed('❌ Usuario no encontrado.')] });

    try {
      await member.timeout(null, 'Unmute manual');
      await sendModLog(guild, 'unmute', targetUser, message.author, 'Silencio retirado');
      return message.reply({ embeds: [createEmbed(`🔊 Silencio retirado a **${targetUser.tag}**.`)] });
    } catch (e) { return message.reply({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); }
  }

  if (command === 'forcename' || command === 'fn') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageNicknames)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `manage_nicknames`', 0xF1C40F)] });
    
    const targetUser = message.mentions.users.first() || (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null);
    const newNick = args.slice(1).join(' ');

    if (!targetUser || !newNick) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('✏️ Guía de Uso: Forcename (Cambiar Apodo)')
        .setDescription('Cambia forzosamente el apodo de un miembro dentro del servidor.')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}fn @usuario NuevoApodo\`` });
      return message.reply({ embeds: [guideEmbed] });
    }

    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) return message.reply({ embeds: [createEmbed('❌ Usuario no encontrado.')] });

    try {
      await member.setNickname(newNick, `Forcename por ${message.author.tag}`);
      await sendModLog(guild, 'forcename', targetUser, message.author, `Nuevo apodo: ${newNick}`);
      return message.reply({ embeds: [createEmbed(`✏️ Apodo cambiado a **${newNick}**.`)] });
    } catch (e) { return message.reply({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); }
  }

  if (command === 'role' || command === 'r') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `manage_roles`', 0xF1C40F)] });
    
    const targetUser = message.mentions.users.first() || (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null);
    const roleQuery = args.slice(1).join(' ').toLowerCase();

    if (!targetUser || !roleQuery) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🎭 Guía de Uso: Role Management')
        .setDescription('Añade o retira automáticamente un rol a un usuario.')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}r @usuario VIP\` o \`${prefix}r @usuario @Rol\`` });
      return message.reply({ embeds: [guideEmbed] });
    }

    const role = message.mentions.roles.first() || guild.roles.cache.get(args[1]) || guild.roles.cache.find(r => r.name.toLowerCase().includes(roleQuery));
    if (!role) return message.reply({ embeds: [createEmbed(`❌ No se encontró el rol \`${roleQuery}\`.`)] });
    const member = await guild.members.fetch(targetUser.id).catch(() => null);

    try {
      if (member.roles.cache.has(role.id)) {
        await member.roles.remove(role);
        return message.reply({ embeds: [createEmbed(`✅ Rol **${role.name}** removido de **${targetUser.tag}**.`)] });
      } else {
        await member.roles.add(role);
        return message.reply({ embeds: [createEmbed(`✅ Rol **${role.name}** entregado a **${targetUser.tag}**.`)] });
      }
    } catch (e) { return message.reply({ embeds: [createEmbed(`⚠️ Error de jerarquía de roles.`, 0xF1C40F)] }); }
  }

  if (command === 'pg') {
    const limit = parseInt(args[0]) || 50;
    try {
      await message.delete().catch(() => {});
      const messages = await message.channel.messages.fetch({ limit: 100 });
      const userMessages = messages.filter(m => m.author.id === message.author.id).first(limit);
      if (userMessages.length > 0) await message.channel.bulkDelete(userMessages, true);
    } catch (e) {}
    return;
  }

  if (command === 'purge' || command === 'clear' || command === 'c') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) return message.reply({ embeds: [createEmbed('⚠️ Te falta: `manage_messages`', 0xF1C40F)] });
    const amount = parseInt(args[0]);

    if (!amount || amount < 1 || amount > 100) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🧹 Guía de Uso: Purge / Clear')
        .setDescription('Elimina en masa un número determinado de mensajes recientes en el canal.')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}purge 20\` — Borra 20 mensajes.` });
      return message.reply({ embeds: [guideEmbed] });
    }

    try {
      await message.delete().catch(() => {});
      const deleted = await message.channel.bulkDelete(amount, true);
      const tempMsg = await message.channel.send({ embeds: [createEmbed(`🧹 Se eliminaron **${deleted.size}** mensajes.`)] });
      setTimeout(() => tempMsg.delete().catch(() => {}), 4000);
    } catch (e) {}
    return;
  }

  if (command === 'nuke') {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return message.reply({ embeds: [createEmbed('⚠️ Te falta el permiso: `manage_channels`', 0xF1C40F)] });
    }

    const channel = message.channel;

    // Verificar si es un canal protegido por servidores de comunidad
    if (guild.rulesChannelId === channel.id || guild.publicUpdatesChannelId === channel.id) {
      return message.reply({ embeds: [createEmbed('❌ **No se puede hacer Nuke en este canal** porque es un canal obligatorio de Servidor de Comunidad designado por Discord.', 0xED4245)] });
    }

    try {
      const position = channel.position;
      const newChannel = await channel.clone({ reason: `Nuke por ${message.author.tag}` });
      await newChannel.setPosition(position);
      await channel.delete(`Nuke por ${message.author.tag}`);
      return newChannel.send({ embeds: [createEmbed('💣 **Nuke**\n\nEste canal ha sido recreado con éxito.')] });
    } catch (e) { 
      return message.reply({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); 
    }
  }
  
  if (command === 'serverinfo' || command === 'si') {
    const owner = await guild.fetchOwner().catch(() => null);
    const createdTimestamp = Math.floor(guild.createdTimestamp / 1000);

    // Conteo de canales por tipo
    const totalChannels = guild.channels.cache.size;
    const textChannels = guild.channels.cache.filter(c => c.isTextBased()).size;
    const voiceChannels = guild.channels.cache.filter(c => c.isVoiceBased()).size;

    // Obtener la URL del avatar/icono del servidor (en HD y animado si es GIF)
    const serverIcon = guild.iconURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setAuthor({ 
        name: `owned by ${owner ? owner.user.username : 'desconocido'} — ${guild.ownerId}`, 
        iconURL: owner ? owner.user.displayAvatarURL({ dynamic: true }) : null 
      })
      .setTitle(guild.name)
      .addFields(
        { 
          name: '📅 Creado', 
          value: `<t:${createdTimestamp}:f> (<t:${createdTimestamp}:R>)`, 
          inline: false 
        },
        { 
          name: `👥 Miembros (${guild.memberCount})`, 
          value: `• **Total:** \`${guild.memberCount}\`\n• **Boosters:** \`${guild.premiumSubscriptionCount || 0}\` (\`Nivel ${guild.premiumTier}\`)`, 
          inline: true 
        },
        { 
          name: `📊 Canales & Roles (${totalChannels + guild.roles.cache.size})`, 
          value: `• **Texto:** \`${textChannels}\` | **Voz:** \`${voiceChannels}\`\n• **Roles:** \`${guild.roles.cache.size}\``, 
          inline: true 
        }
      )
      .setFooter({ text: `Guild ID: ${guild.id}` })
      .setTimestamp();

    // Establecer el avatar del servidor en la miniatura superior derecha
    if (serverIcon) {
      embed.setThumbnail(serverIcon);
    }

    // Si el servidor tiene un banner configurado, se muestra en la parte inferior
    if (guild.bannerURL()) {
      embed.setImage(guild.bannerURL({ size: 1024 }));
    }

    return message.reply({ embeds: [embed] });
  }

  // PERMISOS ADMINISTRATIVOS
  const isOwner = message.author.id === process.env.BOT_OWNER_ID || message.author.id === guild.ownerId;
  const isAdmin = message.member.permissions.has(PermissionFlagsBits.Administrator);
  const isWhl = isWhitelisted(guildId, message.author.id);

  if (!isOwner && !isAdmin && !isWhl) return message.reply({ embeds: [createEmbed('⚠️ Requieres permisos de administrador.', 0xF1C40F)] });

  // SETUP / VSETUP / BAN / HARDBAN / KICK / JAIL / WHITELIST
  if (command === 'setup') {
    const msg = await message.reply({ embeds: [createEmbed('⚙️ Configurando canales privados y logs...')] });
    try {
      let jailRole = guild.roles.cache.find(r => r.name === '[ Silly Cats ] Jail');
      if (!jailRole) jailRole = await guild.roles.create({ name: '[ Silly Cats ] Jail', color: 0x2b2d31, permissions: [] });

      const allChannels = await guild.channels.fetch();
      for (const [, ch] of allChannels) {
        if (!ch || ch.name === '🛡️ SILLY CATS SECURITY' || ch.name === 'jail-mod') continue;
        await ch.permissionOverwrites.edit(jailRole.id, { ViewChannel: false, SendMessages: false }).catch(() => {});
      }

      let secCategory = guild.channels.cache.find(c => c.name === '🛡️ SILLY CATS SECURITY' && c.type === ChannelType.GuildCategory);
      if (!secCategory) secCategory = await guild.channels.create({ name: '🛡️ SILLY CATS SECURITY', type: ChannelType.GuildCategory, permissionOverwrites: [{ id: guild.id, deny: [PermissionFlagsBits.ViewChannel] }] });

      let logChannel = guild.channels.cache.find(c => c.name === 'silly-logs' && c.parentId === secCategory.id);
      if (!logChannel) logChannel = await guild.channels.create({ name: 'silly-logs', type: ChannelType.GuildText, parent: secCategory.id, permissionOverwrites: [{ id: guild.id, deny: [PermissionFlagsBits.ViewChannel] }] });

      let msgLogChannel = guild.channels.cache.find(c => c.name === 'msg-logs' && c.parentId === secCategory.id);
      if (!msgLogChannel) msgLogChannel = await guild.channels.create({ name: 'msg-logs', type: ChannelType.GuildText, parent: secCategory.id, permissionOverwrites: [{ id: guild.id, deny: [PermissionFlagsBits.ViewChannel] }] });

      let jailChannel = guild.channels.cache.find(c => c.name === 'jail-mod' && c.parentId === secCategory.id);
      if (!jailChannel) {
        jailChannel = await guild.channels.create({
          name: 'jail-mod',
          type: ChannelType.GuildText,
          parent: secCategory.id,
          permissionOverwrites: [
            { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: jailRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
          ]
        });
      }

      updateConfig(guildId, { logChannelId: logChannel.id, msgLogChannelId: msgLogChannel.id, jailRoleId: jailRole.id, jailChannelId: jailChannel.id });
      return msg.edit({ embeds: [createEmbed(`✅ **¡Setup completado!**\n\n- **Logs:** <#${logChannel.id}>\n- **Msg Logs:** <#${msgLogChannel.id}>\n- **Jail:** <#${jailChannel.id}>`)] });
    } catch (e) { return msg.edit({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); }
  }

  if (command === 'vsetup') {
    const msg = await message.reply({ embeds: [createEmbed('⚙️ Configurando VoiceMaster...')] });
    try {
      let vcCategory = guild.channels.cache.find(c => c.name === '🔊 VOICE CHANNELS' && c.type === ChannelType.GuildCategory);
      if (!vcCategory) vcCategory = await guild.channels.create({ name: '🔊 VOICE CHANNELS', type: ChannelType.GuildCategory });

      let interfaceChannel = guild.channels.cache.find(c => c.name === 'interface' && c.parentId === vcCategory.id);
      if (!interfaceChannel) interfaceChannel = await guild.channels.create({ name: 'interface', type: ChannelType.GuildText, parent: vcCategory.id });

      let joinChannel = guild.channels.cache.find(c => c.name === 'Join to Create' && c.parentId === vcCategory.id);
      if (!joinChannel) joinChannel = await guild.channels.create({ name: 'Join to Create', type: ChannelType.GuildVoice, parent: vcCategory.id });

      await sendVoiceMasterPanel(interfaceChannel);
      return msg.edit({ embeds: [createEmbed(`✅ **VoiceMaster configurado!**\n- Panel: <#${interfaceChannel.id}>`)] });
    } catch (e) { return msg.edit({ embeds: [createEmbed(`❌ Error: \`${e.message}\``)] }); }
  }

  // BAN & HARDBAN GUÍA Y ACCIONES
  if (command === 'ban' || command === 'hardban' || command === 'hb') {
    const isHard = command === 'hardban' || command === 'hb';
    const targetUser = message.mentions.users.first() || (args[0] ? await message.client.users.fetch(args[0]).catch(() => null) : null);

    if (!targetUser) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle(isHard ? '⚡ Guía de Uso: Hardban' : '🔨 Guía de Uso: Ban')
        .setDescription(
          isHard 
            ? '**¿Para qué sirve?**\nBanea a un usuario y registra su ID en la base de datos SQLite. Si intenta volver a entrar con cualquier invitación, el bot lo expulsará inmediatamente.' 
            : '**¿Para qué sirve?**\nExpulsa y prohíbe la entrada a un usuario registrando el motivo en los logs de auditoría.'
        )
        .addFields(
          { name: '📌 **Sintaxis**', value: `\`${prefix}${command} @usuario [razón]\` o \`${prefix}${command} ID_USUARIO [razón]\`` },
          { name: '💡 **Ejemplo**', value: `\`${prefix}${command} @usuario Ataque / Nuke\`` }
        );
      return message.reply({ embeds: [guideEmbed] });
    }

    const reason = args.slice(1).join(' ') || (isHard ? 'Hardban permanente' : 'No reason provided');

    try {
      if (isHard) addHardban(guildId, targetUser.id, reason);
      await guild.members.ban(targetUser.id, { deleteMessageSeconds: isHard ? 604800 : 0, reason });
      await sendModLog(guild, isHard ? 'hardban' : 'ban', targetUser, message.author, reason);
      return message.reply({ embeds: [createEmbed(isHard ? `⚡ **${targetUser.tag}** recibió **Hardban permanente**.` : `✅ **${targetUser.tag}** baneado.`)] });
    } catch (err) { return message.reply({ embeds: [createEmbed(`⚠️ Error al banear. Verifica que mi rol esté por encima del usuario.`, 0xF1C40F)] }); }
  }

  if (command === 'unban') {
    const userId = args[0];
    if (!userId) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🔓 Guía de Uso: Unban')
        .setDescription('Retira el ban a una ID de usuario y borra su registro si poseía un Hardban.')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}unban 123456789012345678\`` });
      return message.reply({ embeds: [guideEmbed] });
    }

    const targetUser = await message.client.users.fetch(userId).catch(() => ({ id: userId, username: userId }));

    try {
      removeHardban(guildId, userId);
      await guild.members.unban(userId);
      await sendModLog(guild, 'unban', targetUser, message.author, 'Desbaneado');
      return message.reply({ embeds: [createEmbed(`✅ Usuario \`${userId}\` desbaneado.`)] });
    } catch (e) { return message.reply({ embeds: [createEmbed('❌ La ID no está baneada.')] }); }
  }

  if (command === 'kick') {
    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('👢 Guía de Uso: Kick')
        .setDescription('Expulsa a un usuario del servidor (podrá volver a ingresar si posee una invitación).')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}kick @usuario Incumplir reglas\`` });
      return message.reply({ embeds: [guideEmbed] });
    }

    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) return message.reply({ embeds: [createEmbed('❌ El usuario no está en el servidor.')] });

    const reason = args.slice(1).join(' ') || 'No reason provided';
    try {
      await member.kick(reason);
      await sendModLog(guild, 'kick', targetUser, message.author, reason);
      return message.reply({ embeds: [createEmbed(`✅ **${targetUser.tag}** expulsado.`)] });
    } catch (e) { return message.reply({ embeds: [createEmbed(`⚠️ Fallo al expulsar.`, 0xF1C40F)] }); }
  }

  // JAIL & UNJAIL GUÍA Y ACCIONES
  if (command === 'jail') {
    const targetUser = message.mentions.users.first();

    if (!targetUser) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🔒 Guía de Uso: Jail (Cárcel)')
        .setDescription(
          '**¿Para qué sirve?**\nAísla por completo a un usuario. Guarda todos sus roles en la base de datos, se los remueve y le otorga el rol de cárcel impidiéndole ver cualquier otro canal del servidor.'
        )
        .addFields(
          { name: '⚙️ **Requisito Previos**', value: `Debes haber ejecutado \`${prefix}setup\` una vez para crear el rol e isla de la cárcel.` },
          { name: '📌 **Sintaxis**', value: `\`${prefix}jail @usuario [razón]\`` },
          { name: '💡 **Ejemplo**', value: `\`${prefix}jail @usuario Mala conducta\`` }
        );
      return message.reply({ embeds: [guideEmbed] });
    }

    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) return message.reply({ embeds: [createEmbed('❌ El usuario no está en el servidor.')] });

    const cfg = getConfig(guildId);
    if (!cfg.jailRoleId) return message.reply({ embeds: [createEmbed(`❌ Ejecuta \`${prefix}setup\` primero para crear el sistema de cárcel.`)] });

    const rolesToSave = member.roles.cache.filter(r => r.id !== guildId && r.id !== cfg.jailRoleId).map(r => r.id);
    setJailedUser(guildId, member.id, rolesToSave);

    await member.roles.remove(rolesToSave).catch(() => {});
    await member.roles.add(cfg.jailRoleId).catch(() => {});

    const reason = args.slice(1).join(' ') || 'No reason provided';
    await sendModLog(guild, 'jail', targetUser, message.author, reason);
    return message.reply({ embeds: [createEmbed(`🔒 **${targetUser.tag}** enviado a cárcel.`)] });
  }

  if (command === 'unjail') {
    const targetUser = message.mentions.users.first();

    if (!targetUser) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🔓 Guía de Uso: Unjail')
        .setDescription('Libera a un usuario de la cárcel y le devuelve automáticamente todos los roles que tenía antes de ser encarcelado.')
        .addFields({ name: '📌 **Ejemplo**', value: `\`${prefix}unjail @usuario\`` });
      return message.reply({ embeds: [guideEmbed] });
    }

    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) return message.reply({ embeds: [createEmbed('❌ El usuario no está en el servidor.')] });

    const cfg = getConfig(guildId);
    const savedRoles = getJailedUserRoles(guildId, member.id);

    if (cfg.jailRoleId) await member.roles.remove(cfg.jailRoleId).catch(() => {});
    if (savedRoles) await member.roles.add(savedRoles).catch(() => {});
    removeJailedUser(guildId, member.id);

    await sendModLog(guild, 'unjail', targetUser, message.author, 'Liberado de cárcel');
    return message.reply({ embeds: [createEmbed(`🔓 **${targetUser.tag}** liberado de cárcel.`)] });
  }

  // WHITELIST GUÍA Y ACCIONES
  if (command === 'whitelist' || command === 'wl') {
    const sub = args[0]?.toLowerCase();
    const targetUser = message.mentions.users.first();

    if (!sub || (sub !== 'add' && sub !== 'remove' && sub !== 'list')) {
      const guideEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setTitle('🛡️ Guía de Uso: Whitelist (Lista Blanca)')
        .setDescription(
          '**¿Para qué sirve?**\nExime a usuarios o administradores de confianza del sistema **Anti-Nuke**. Los miembros en Whitelist no activarán el bloqueo ni sanciones automáticas si realizan cambios masivos.'
        )
        .addFields(
          { name: '➕ **Añadir a Whitelist**', value: `\`${prefix}whitelist add @usuario\`` },
          { name: '➖ **Remover de Whitelist**', value: `\`${prefix}whitelist remove @usuario\`` },
          { name: '📋 **Ver Lista Blanca**', value: `\`${prefix}whitelist list\`` }
        )
        .setFooter({ text: 'Nota: Usa esta función únicamente con miembros de extrema confianza.' });
      return message.reply({ embeds: [guideEmbed] });
    }

    if (sub === 'add' && targetUser) { 
      addWhitelist(guildId, targetUser.id); 
      return message.reply({ embeds: [createEmbed(`✅ **${targetUser.tag}** fue añadido a la Whitelist del Anti-Nuke.`)] }); 
    }
    
    if (sub === 'remove' && targetUser) { 
      removeWhitelist(guildId, targetUser.id); 
      return message.reply({ embeds: [createEmbed(`✅ **${targetUser.tag}** fue eliminado de la Whitelist.`)] }); 
    }
    
    if (sub === 'list') { 
      const list = getWhitelist(guildId);
      return message.reply({ embeds: [createEmbed(list.length ? `📋 **Lista de miembros en Whitelist:**\n\n${list.map(id => `• <@${id}> (\`${id}\`)`).join('\n')}` : 'ℹ️ La Whitelist está vacía actualmente.')] }); 
    }
  }
}

module.exports = { handleCommands };