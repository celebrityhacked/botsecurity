const { getJailedUserRoles, getConfig } = require('../database');

function setupJailWatcher(client) {
  client.on('guildMemberAdd', async (member) => {
    const guild = member.guild;
    const cfg = getConfig(guild.id);
    const jailedRoles = getJailedUserRoles(guild.id, member.id);

    if (jailedRoles && cfg.jailRoleId) {
      try {
        // Si reingresa y seguía en jail, le quitamos los roles que traiga y le ponemos el rol de cárcel
        const currentRoles = member.roles.cache.filter(r => r.id !== guild.id);
        if (currentRoles.size > 0) {
          await member.roles.remove(currentRoles);
        }
        await member.roles.add(cfg.jailRoleId);
      } catch (e) {}
    }
  });
}

module.exports = { setupJailWatcher };