const { PermissionFlagsBits } = require('discord.js');
const { getConfig } = require('../database');
const { sendSecurityLog } = require('../logger');

// Map de almacenamiento de uniones recientes: GuildID -> Array<Timestamp>
const joinTracker = new Map();

function setupAntiRaid(client) {
  client.on('guildMemberAdd', async (member) => {
    const guild = member.guild;
    const cfg = getConfig(guild.id);
    if (!cfg.antiraid) return;

    const now = Date.now();
    if (!joinTracker.has(guild.id)) {
      joinTracker.set(guild.id, []);
    }

    const joins = joinTracker.get(guild.id);
    joins.push(now);

    // Filtrar uniones que sobrepasen la ventana temporal
    const recentJoins = joins.filter(t => now - t <= cfg.raidWindowMs);
    joinTracker.set(guild.id, recentJoins);

    // Si supera el umbral configurado -> Modo Anti-Raid activado
    if (recentJoins.length >= cfg.raidThreshold) {
      try {
        const me = guild.members.me;
        if (me.permissions.has(PermissionFlagsBits.ManageGuild)) {
          // Aumenta el nivel de verificación del servidor temporalmente a HIGH
          await guild.setVerificationLevel(3, 'Anti-Raid: Detección de entrada masiva');
        }

        await sendSecurityLog(guild, {
          action: 'ANTI_RAID_TRIGGERED',
          executor: null,
          target: `${recentJoins.length} miembros en ${cfg.raidWindowMs / 1000}s`,
          success: true,
          restored: false,
          details: `Se elevó la verificación a nivel ALTO automáticamente.`
        });
      } catch (err) {
        console.error('[ANTI_RAID_ERROR]', err.message);
      }
    }
  });
}

module.exports = { setupAntiRaid };