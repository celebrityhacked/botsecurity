const { isHardbanned, removeHardban } = require('../database');
const { sendSecurityLog } = require('../logger');

function setupHardbanWatcher(client) {
  // Si un usuario entra al servidor y está en la lista de Hardban, lo re-banea al instante
  client.on('guildMemberAdd', async (member) => {
    const guild = member.guild;
    if (isHardbanned(guild.id, member.id)) {
      try {
        await member.ban({ reason: '[BLEED HARDBAN] El usuario posee un baneo permanente activo.' });
        await sendSecurityLog(guild, {
          action: 'HARDBAN_ENFORCED',
          executor: null,
          target: `${member.user.tag} (${member.id})`,
          success: true,
          restored: false,
          details: `El usuario intentó unirse pero fue bloqueado por Hardban persistente.`
        });
      } catch (e) {}
    }
  });

  // Si alguien lo desbanea manualmente desde la interfaz de Discord, verificamos si era un Hardban
  client.on('guildBanRemove', async (ban) => {
    const guild = ban.guild;
    if (isHardbanned(guild.id, ban.user.id)) {
      // Si intentaron quitarle el ban manual, lo re-baneamos automáticamente de inmediato
      try {
        await guild.members.ban(ban.user.id, { reason: '[BLEED HARDBAN] Intento de evasión de baneo permanente.' });
      } catch (e) {}
    }
  });
}

module.exports = { setupHardbanWatcher };