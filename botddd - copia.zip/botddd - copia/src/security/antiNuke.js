const { AuditLogEvent, EmbedBuilder } = require('discord.js');
const { isWhitelisted, getConfig } = require('../database');
const { sendModLog, sendMessageDeleteLog } = require('../logger');

const recentlyPunished = new Set();

function setupAntiNuke(client) {
  console.log('🛡️ [ANTI-NUKE] Escuchador de eventos activo.');

  // Registrar borrado de mensajes
  client.on('messageDelete', async (message) => {
    if (!message.guild || message.author?.bot) return;
    await sendMessageDeleteLog(message.guild, message);
  });

  // Registrar creación de canales
  client.on('channelCreate', async (channel) => {
    if (!channel.guild) return;
    const guild = channel.guild;
    const cfg = getConfig(guild.id);
    if (!cfg || !cfg.logChannelId) return;

    const logChannel = guild.channels.cache.get(cfg.logChannelId) || await guild.channels.fetch(cfg.logChannelId).catch(() => null);
    if (!logChannel) return;

    let executor = 'Desconocido';
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelCreate }).catch(() => null);
      if (logs && logs.entries.first()) {
        executor = logs.entries.first().executor.tag;
      }
    } catch (e) {}

    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('➕ Canal Creado')
      .setDescription(`**Canal:** #${channel.name} (\`${channel.id}\`)\n**Creado por:** \`${executor}\``)
      .setTimestamp();

    await logChannel.send({ embeds: [embed] }).catch(() => {});
  });

  // Evento de eliminación de canales (Anti-Nuke con Whitelist)
  client.on('channelDelete', async (channel) => {
    if (!channel.guild) return;
    const guild = channel.guild;
    const cfg = getConfig(guild.id);

    if (cfg && cfg.logChannelId) {
      const logChannel = guild.channels.cache.get(cfg.logChannelId) || await guild.channels.fetch(cfg.logChannelId).catch(() => null);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor(0xED4245)
          .setTitle('🗑️ Canal Eliminado')
          .setDescription(`**Canal:** #${channel.name} (\`${channel.id}\`)`)
          .setTimestamp();
        await logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    if (cfg && cfg.antinuke === false) return;

    let executor = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete }).catch(() => null);
        if (logs) {
          const entry = logs.entries.first();
          if (entry && (Date.now() - entry.createdTimestamp < 10000)) {
            executor = entry.executor;
            break;
          }
        }
      } catch (e) {}
    }

    if (executor) {
      const isOwner = executor.id === guild.ownerId || executor.id === process.env.BOT_OWNER_ID;
      const whitelisted = isWhitelisted(guild.id, executor.id);
      const isSelf = executor.id === client.user.id;

      if (isOwner || whitelisted || isSelf) {
        console.log(`✅ [ANTI-NUKE] Borrado por ${executor.tag} (Autorizado/Whitelist). El canal NO se recreará.`);
        return;
      }

      if (!recentlyPunished.has(executor.id)) {
        recentlyPunished.add(executor.id);
        setTimeout(() => recentlyPunished.delete(executor.id), 10000);

        try {
          await guild.members.ban(executor.id, { reason: '[SILLY CATS ANTI-NUKE] Borrado no autorizado de canal' });
          await sendModLog(guild, 'ban', executor, client.user, 'Anti-Nuke: Borrado no autorizado de canal').catch(() => {});
        } catch (err) {}
      }
    }

    try {
      await guild.channels.create({
        name: channel.name,
        type: channel.type,
        topic: channel.topic,
        nsfw: channel.nsfw,
        bitrate: channel.bitrate,
        userLimit: channel.userLimit,
        parent: channel.parentId,
        permissionOverwrites: channel.permissionOverwrites.cache
      });
    } catch (e) {}
  });
}

module.exports = { setupAntiNuke };