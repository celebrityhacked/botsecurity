const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('./database');

async function sendModLog(guild, action, target, executor, reason) {
  try {
    const cfg = getConfig(guild.id);
    if (!cfg.logChannelId) return;

    const logChannel = guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setTitle(`🛡️ Audit Log: ${action.toUpperCase()}`)
      .addFields(
        { name: 'Target', value: target ? `${target} (\`${target.id}\`)` : 'N/A', inline: true },
        { name: 'Executor', value: executor ? `${executor} (\`${executor.id}\`)` : 'System', inline: true },
        { name: 'Reason', value: reason || 'No reason provided' }
      )
      .setTimestamp();

    await logChannel.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    console.error('Error sending mod log:', err);
  }
}

// Handler para registrar criação de mensagens (se configurado)
async function handleMessageLogger(message) {
  // Opcional: Implemente aqui logs de criação de mensagens se desejar
  return;
}

// Handler para registrar mensagens deletadas
async function handleMessageDeleteLogger(message) {
  try {
    if (!message.guild || message.author?.bot) return;

    const cfg = getConfig(message.guild.id);
    if (!cfg.msgLogChannelId) return;

    const logChannel = message.guild.channels.cache.get(cfg.msgLogChannelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setAuthor({ 
        name: message.author ? message.author.tag : 'Usuario desconocido', 
        iconURL: message.author?.displayAvatarURL({ dynamic: true }) 
      })
      .setDescription(`🗑️ **Mensaje eliminado en** ${message.channel}\n\n**Contenido:**\n${message.content || '*Sin contenido de texto (solo imagen/archivo)*'}`)
      .setFooter({ text: `User ID: ${message.author?.id || 'Desconocido'}` })
      .setTimestamp();

    if (message.attachments?.size > 0) {
      embed.addFields({ name: 'Adjuntos', value: `${message.attachments.size} archivo(s)` });
    }

    await logChannel.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    console.error('Error in handleMessageDeleteLogger:', err);
  }
}

// Handler para registrar mensagens editadas
async function handleMessageUpdateLogger(oldMessage, newMessage) {
  try {
    if (!oldMessage.guild || oldMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;

    const cfg = getConfig(oldMessage.guild.id);
    if (!cfg.msgLogChannelId) return;

    const logChannel = oldMessage.guild.channels.cache.get(cfg.msgLogChannelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor(0xF1C40F)
      .setAuthor({ 
        name: oldMessage.author ? oldMessage.author.tag : 'Usuario desconocido', 
        iconURL: oldMessage.author?.displayAvatarURL({ dynamic: true }) 
      })
      .setDescription(`✏️ **Mensaje editado en** ${oldMessage.channel} ([Ir al mensaje](${newMessage.url}))`)
      .addFields(
        { name: 'Antes', value: oldMessage.content || '*Vacio*' },
        { name: 'Después', value: newMessage.content || '*Vacio*' }
      )
      .setFooter({ text: `User ID: ${oldMessage.author?.id || 'Desconocido'}` })
      .setTimestamp();

    await logChannel.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    console.error('Error in handleMessageUpdateLogger:', err);
  }
}

module.exports = {
  sendModLog,
  handleMessageLogger,
  handleMessageDeleteLogger,
  handleMessageUpdateLogger
};