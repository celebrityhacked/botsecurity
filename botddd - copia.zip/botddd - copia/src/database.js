const Database = require('better-sqlite3');
const path = require('path');

// Inicialización de la base de datos SQLite en la carpeta del proyecto
const db = new Database(path.join(__dirname, '..', 'bot_database.sqlite'));

/**
 * Inicializa la estructura de tablas si no existen
 */
function initDatabase() {
  // Tabla de configuración general por servidor
  db.prepare(`
    CREATE TABLE IF NOT EXISTS guild_config (
      guild_id TEXT PRIMARY KEY,
      log_channel_id TEXT,
      msg_log_channel_id TEXT,
      jail_role_id TEXT,
      jail_channel_id TEXT,
      antinuke INTEGER DEFAULT 1
    )
  `).run();

  // Tabla de Whitelist (Usuarios exentos de protecciones)
  db.prepare(`
    CREATE TABLE IF NOT EXISTS whitelist (
      guild_id TEXT,
      user_id TEXT,
      PRIMARY KEY (guild_id, user_id)
    )
  `).run();

  // Tabla de Hardbans (Bans permanentes guardados en SQLite)
  db.prepare(`
    CREATE TABLE IF NOT EXISTS hardbans (
      guild_id TEXT,
      user_id TEXT,
      reason TEXT,
      PRIMARY KEY (guild_id, user_id)
    )
  `).run();

  // Tabla de usuarios encarcelados (guarda sus roles anteriores)
  db.prepare(`
    CREATE TABLE IF NOT EXISTS jailed_users (
      guild_id TEXT,
      user_id TEXT,
      roles TEXT,
      PRIMARY KEY (guild_id, user_id)
    )
  `).run();

  console.log('💾 [DATABASE] Tablas de SQLite inicializadas correctamente.');
}

// ==========================================
// FUNCIONES DE CONFIGURACIÓN
// ==========================================

function getConfig(guildId) {
  const row = db.prepare('SELECT * FROM guild_config WHERE guild_id = ?').get(guildId);
  return row ? {
    logChannelId: row.log_channel_id,
    msgLogChannelId: row.msg_log_channel_id,
    jailRoleId: row.jail_role_id,
    jailChannelId: row.jail_channel_id,
    antinuke: row.antinuke === 1
  } : {};
}

function updateConfig(guildId, config) {
  const current = getConfig(guildId);
  const logChannelId = config.logChannelId !== undefined ? config.logChannelId : current.logChannelId || null;
  const msgLogChannelId = config.msgLogChannelId !== undefined ? config.msgLogChannelId : current.msgLogChannelId || null;
  const jailRoleId = config.jailRoleId !== undefined ? config.jailRoleId : current.jailRoleId || null;
  const jailChannelId = config.jailChannelId !== undefined ? config.jailChannelId : current.jailChannelId || null;
  const antinuke = config.antinuke !== undefined ? (config.antinuke ? 1 : 0) : (current.antinuke !== false ? 1 : 0);

  db.prepare(`
    INSERT INTO guild_config (guild_id, log_channel_id, msg_log_channel_id, jail_role_id, jail_channel_id, antinuke)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET
      log_channel_id = excluded.log_channel_id,
      msg_log_channel_id = excluded.msg_log_channel_id,
      jail_role_id = excluded.jail_role_id,
      jail_channel_id = excluded.jail_channel_id,
      antinuke = excluded.antinuke
  `).run(guildId, logChannelId, msgLogChannelId, jailRoleId, jailChannelId, antinuke);
}

// ==========================================
// FUNCIONES DE WHITELIST
// ==========================================

function isWhitelisted(guildId, userId) {
  const row = db.prepare('SELECT 1 FROM whitelist WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
  return !!row;
}

function addWhitelist(guildId, userId) {
  db.prepare('INSERT OR IGNORE INTO whitelist (guild_id, user_id) VALUES (?, ?)').run(guildId, userId);
}

function removeWhitelist(guildId, userId) {
  db.prepare('DELETE FROM whitelist WHERE guild_id = ? AND user_id = ?').run(guildId, userId);
}

function getWhitelist(guildId) {
  const rows = db.prepare('SELECT user_id FROM whitelist WHERE guild_id = ?').all(guildId);
  return rows.map(r => r.user_id);
}

// ==========================================
// FUNCIONES DE HARDBAN
// ==========================================

function addHardban(guildId, userId, reason) {
  db.prepare('INSERT OR REPLACE INTO hardbans (guild_id, user_id, reason) VALUES (?, ?, ?)').run(guildId, userId, reason);
}

function removeHardban(guildId, userId) {
  db.prepare('DELETE FROM hardbans WHERE guild_id = ? AND user_id = ?').run(guildId, userId);
}

// ==========================================
// FUNCIONES DE CÁRCEL (JAIL)
// ==========================================

function setJailedUser(guildId, userId, rolesArray) {
  const rolesStr = JSON.stringify(rolesArray || []);
  db.prepare('INSERT OR REPLACE INTO jailed_users (guild_id, user_id, roles) VALUES (?, ?, ?)').run(guildId, userId, rolesStr);
}

function getJailedUserRoles(guildId, userId) {
  const row = db.prepare('SELECT roles FROM jailed_users WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
  if (!row) return null;
  try {
    return JSON.parse(row.roles);
  } catch (e) {
    return [];
  }
}

function removeJailedUser(guildId, userId) {
  db.prepare('DELETE FROM jailed_users WHERE guild_id = ? AND user_id = ?').run(guildId, userId);
}

// Exportar todas las funciones requeridas por index.js y securityCommands.js
module.exports = {
  initDatabase,
  getConfig,
  updateConfig,
  isWhitelisted,
  addWhitelist,
  removeWhitelist,
  getWhitelist,
  addHardban,
  removeHardban,
  setJailedUser,
  getJailedUserRoles,
  removeJailedUser
};