# 🩸 Bleed-Style Discord Security Bot

Bot de seguridad de máxima velocidad para Discord, diseñado con arquitectura orientada a eventos para la prevención activa de Nuke y Raid.

## 🚀 Instalación Rápida
1. Instala Node.js v18+.
2. Clona/descarga este proyecto en una carpeta.
3. Configura `.env` con tu token y tu ID.
4. Ejecuta `npm install`.
5. Inicia el bot con `npm start`.