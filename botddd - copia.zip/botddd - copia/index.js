require('dotenv').config();
const { Client, GatewayIntentBits, Partials, ActivityType, Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AuditLogEvent } = require('discord.js');
const { initDatabase, isWhitelisted, getConfig } = require('./src/database');
const { handleCommands } = require('./src/commands/securityCommands');
const { handleVoiceStateUpdate } = require('./src/modules/voiceMaster');
const { handleMessageLogger, handleMessageDeleteLogger, handleMessageUpdateLogger, sendModLog } = require('./src/logger');

// Inicializar la base de datos SQLite
initDatabase();

// Configuración del cliente con todos los Intents necesarios
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildPresences
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User]
});

// Map global para almacenar los mensajes eliminados por canal (Sistema Snipe)
if (!global.snipes) global.snipes = new Map();

// EVENTO: Bot listo
client.once(Events.ClientReady, async () => {
  console.log(`\n==========================================`);
  console.log(`🐾 Silly Cats Security iniciado como: ${client.user.tag}`);
  console.log(`⚙️  Servidores activos: ${client.guilds.cache.size}`);
  console.log(`==========================================\n`);

  client.user.setPresence({
    activities: [{ name: ',help • Silly Cats', type: ActivityType.Watching }],
    status: 'dnd'
  });
});

// EVENTO: ANTI-NUKE (Detección de eliminación de canales)
client.on(Events.ChannelDelete, async (channel) => {
  if (!channel.guild) return;

  const guild = channel.guild;
  const cfg = getConfig(guild.id);

  // Si el anti-nuke está desactivado, ignorar
  if (cfg.antinuke === false) return;

  try {
    // Consultar Audit Logs para saber quién eliminó el canal
    const fetchedLogs = await guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.ChannelDelete
    }).catch(() => null);

    if (!fetchedLogs) return;

    const deletionLog = fetchedLogs.entries.first();
    if (!deletionLog) return;

    const { executor, target } = deletionLog;

    // Verificar si la acción fue reciente (últimos 5 segundos) y sobre este canal
    if (!executor || executor.bot || target.id !== channel.id) return;

    // SI EL EJECUTOR ESTÁ EN WHITELIST O ES EL OWNER, IGNORAR
    if (executor.id === guild.ownerId || isWhitelisted(guild.id, executor.id)) {
      console.log(`🛡️ [ANTI-NUKE] Canal #${channel.name} eliminado por usuario en Whitelist (${executor.tag}). Acción permitida.`);
      return;
    }

    console.log(`🚨 [ANTI-NUKE] Detección: ${executor.tag} eliminó el canal #${channel.name} sin estar en Whitelist.`);

    // 1. RECREAR EL CANAL ELIMINADO
    const newChannel = await channel.clone({
      reason: `[Silly Cats Anti-Nuke] Recreando canal eliminado por ${executor.tag}`
    }).catch(() => null);

    if (newChannel) {
      await newChannel.setPosition(channel.position).catch(() => {});
      await newChannel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xED4245)
            .setTitle('🛡️ Protección Anti-Nuke Activada')
            .setDescription(`Este canal fue eliminado por **${executor.tag}** (\`${executor.id}\`) sin autorización y ha sido restaurado automáticamente.`)
        ]
      }).catch(() => {});
    }

    // 2. SANCIONAR AL EJECUTOR (Baneo de seguridad)
    const member = await guild.members.fetch(executor.id).catch(() => null);
    
    if (member) {
      // Intentar banear al atacante
      await member.ban({ reason: '[Silly Cats Anti-Nuke] Eliminación no autorizada de canales' })
        .then(async () => {
          await sendModLog(guild, 'antinuke_ban', executor, client.user, `Baneado por eliminar el canal #${channel.name}`);
        })
        .catch(async () => {
          // Si no se le puede banear por jerarquía de roles, removerle todos los roles de administración
          console.log(`⚠️ No se pudo banear a ${executor.tag}. Quitando roles por seguridad.`);
          const adminRoles = member.roles.cache.filter(r => r.id !== guild.id && r.permissions.has('Administrator'));
          await member.roles.remove(adminRoles).catch(() => {});
        });
    }
  } catch (err) {
    console.error('Error en evento Anti-Nuke ChannelDelete:', err);
  }
});

// EVENTO: Bienvenida cuando el bot entra a un servidor
client.on(Events.GuildCreate, async (guild) => {
  try {
    const channel = guild.channels.cache.find(
      c => c.isTextBased() && c.permissionsFor(guild.members.me).has('SendMessages')
    );

    if (!channel) return;

    const ownerId = process.env.BOT_OWNER_ID;
    let botOwner = null;
    
    if (ownerId) {
      botOwner = await client.users.fetch(ownerId, { force: true }).catch(() => null);
    }

    const ownerTag = botOwner ? botOwner.username : 'icé';
    const ownerAvatar = botOwner ? botOwner.displayAvatarURL({ dynamic: true, size: 512 }) : client.user.displayAvatarURL();

    const welcomeEmbed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setDescription(
        `Gracias por añadir **Silly Cats Security** a **${guild.name}**. Silly Cats es un bot multipropósito de alta seguridad, moderación, VoiceMaster e interacciones diseñado para mantener tu servidor seguro y activo.\n\n` +
        `El prefijo predeterminado es: \`,\` . Si necesitas ayuda con los comandos, simplemente ejecuta \`,help\` o \`,cmds\` en cualquier canal.`
      )
      .addFields({
        name: '⚙️ **Get set up**',
        value: `Configura el sistema de moderación, VoiceMaster, filtros y Anti-Nuke de forma automática. Tú eliges las categorías y canales.\n\n` +
               `¿Prefieres comandos? Ejecuta \`,setup\` para la seguridad básica o \`,vsetup\` para el panel VoiceMaster.`
      })
      .setFooter({
        text: `Developed & Owned by @${ownerTag} • Silly Cats Security`,
        iconURL: ownerAvatar
      });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Documentación')
        .setCustomId('welcome_help_btn')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setLabel('Creador')
        .setURL(ownerId ? `https://discord.com/users/${ownerId}` : 'https://discord.com')
        .setStyle(ButtonStyle.Link)
    );

    await channel.send({ embeds: [welcomeEmbed], components: [row] }).catch(() => {});
  } catch (err) {
    console.error('Error al enviar mensaje de bienvenida en guildCreate:', err);
  }
});

// EVENTO: Captura y registro de mensajes eliminados
client.on('messageDelete', async (message) => {
  if (!message || message.author?.bot) return;

  if (message.content || message.attachments?.size > 0) {
    const channelSnipes = global.snipes.get(message.channel.id) || [];
    
    channelSnipes.unshift({
      content: message.content || null,
      author: message.author,
      image: message.attachments?.first()?.url || null,
      timestamp: Date.now()
    });

    if (channelSnipes.length > 30) channelSnipes.pop();
    global.snipes.set(message.channel.id, channelSnipes);
  }

  await handleMessageDeleteLogger(message);
});

// EVENTO: Edición de mensajes
client.on('messageUpdate', async (oldMessage, newMessage) => {
  await handleMessageUpdateLogger(oldMessage, newMessage);
});

// EVENTO: Mensajes recibidos
client.on('messageCreate', async (message) => {
  if (!message.guild || message.author.bot) return;

  await handleMessageLogger(message);
  await handleCommands(message);
});

// EVENTO: Cambios en canales de voz
client.on('voiceStateUpdate', async (oldState, newState) => {
  await handleVoiceStateUpdate(oldState, newState);
});

// EVENTO: Interacciones con botones
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'welcome_help_btn') {
    return interaction.reply({
      content: '🐾 Para comenzar a configurar el bot, ejecuta `,setup` en un canal privado. Para ver la lista completa de comandos usa `,help`.',
      ephemeral: true
    });
  }

  const { handleVoiceMasterButtons } = require('./src/modules/voiceMaster');
  await handleVoiceMasterButtons(interaction);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ Error no capturado (Unhandled Rejection):', reason);
});

process.on('uncaughtException', (err) => {
  console.error('💥 Excepción no capturada (Uncaught Exception):', err);
});

client.login(process.env.DISCORD_TOKEN);